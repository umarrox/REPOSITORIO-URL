﻿Random random = new Random();
int numeroSecreto = random.Next(0, 51); // Número entre 0 y 50
int intento = 0;

Console.WriteLine("Adivina el número entre 0 y 50:");

while (true)
{
    try
    {
        Console.Write("Ingresa un número: ");
        intento = int.Parse(Console.ReadLine());

        if (intento == numeroSecreto)
        {
            Console.WriteLine("¡Correcto! Adivinaste el número.");
            break;
        }
        else if (intento < numeroSecreto)
        {
            Console.WriteLine("El número secreto es mayor. Intenta otra vez.");
        }
        else
        {
            Console.WriteLine("El número secreto es menor. Intenta otra vez.");
        }
    }
    catch (FormatException)
    {
        Console.WriteLine(" Por favor, ingresa un número válido.");
    }
}